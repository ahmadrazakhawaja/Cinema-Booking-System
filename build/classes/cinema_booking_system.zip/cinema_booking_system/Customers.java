/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema_booking_system;

/**
 *
 * @author Muhammad Affan
 */
public class Customers {
    
    private int CustomerID;
    private String CustomerName;
    private long MobileNo;
     private long TelephoneNo;
    private String H_address;
    
    public Customers(int CustomerID, String CustomerName, long MobileNo, long TelephoneNo, String H_address){
        
        this.CustomerID = CustomerID;
        this.CustomerName = CustomerName;
        this.MobileNo = MobileNo;
        this.TelephoneNo = TelephoneNo;
        this.H_address = H_address;
        
    }

    public void setCustomerID(int CustomerID) {
        this.CustomerID = CustomerID;
    }

    public void setCustomerName(String CustomerName) {
        this.CustomerName = CustomerName;
    }

    public void setMobileNo(long MobileNo) {
        this.MobileNo = MobileNo;
    }

    public void setTelephoneNo(long TelephoneNo) {
        this.TelephoneNo = TelephoneNo;
    }

    public void setH_address(String H_address) {
        this.H_address = H_address;
    }

    @Override
    public String toString() {
        return "Customers:" + "CustomerID=" + CustomerID + ", CustomerName=" + CustomerName + ", MobileNo=" + MobileNo + ", TelephoneNo=" + TelephoneNo + ", H_address=" + H_address;
    }
    
    
}
