/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema_booking_system;

/**
 *
 * @author Muhammad Affan
 */
public class Seat {
    private int SeatID;
    private int xPosition;
    private int yPosition;
   
    
    
    public Seat(int SeatID, int xPosition, int yPosition ){
        this.SeatID = SeatID;
        this.xPosition = xPosition;
        this.yPosition = yPosition;
        
        
    }

    public void setSeatID(int SeatID) {
        this.SeatID = SeatID;
    }

    public void setxPosition(int xPosition) {
        this.xPosition = xPosition;
    }

    public void setyPosition(int yPosition) {
        this.yPosition = yPosition;
    }

    @Override
    public String toString() {
        return "Seat: " + "SeatID = " + SeatID + ", row: " + xPosition + ", column: " + yPosition;
    }
    
    
}
