/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema_booking_system;

/**
 *
 * @author Muhammad Affan
 */
public class Room {
    private int RoomId;
   private  int capacity;
   private String category;
   
   
   public Room(int Roomid, int capacity, String category){
       this.RoomId = Roomid;
       this.capacity = capacity;
       this.category = category;
       
   }

    @Override
    public String toString() {
        return "Room: " + "RoomId=" + RoomId + ", capacity=" + capacity + ", category=" + category;
    }
   
}
