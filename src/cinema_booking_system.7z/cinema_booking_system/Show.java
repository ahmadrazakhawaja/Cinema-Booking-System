/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema_booking_system;

/**
 *
 * @author Muhammad Affan
 */
public class Show {
  
   private String title;
   public String category;
   public static int prices;
 
   public static int Quantity;
   private Session s;
   private Payment payment;
  
   

    public Show(String title, String category, int prices, int Quantity, Session s, Payment payment) {
        this.title = title;
        this.category = category;
        this.prices = prices;
        this.Quantity = Quantity;
        this.s = s;
        this.payment = payment;
        
    }

    @Override
    public String toString() {
        return "Show: " + "Title= " + title + "\n Category= " + category + "\n " + s + "\n" + payment ;
    }
    
    
   
   
   
   
   
    
   
    
}
