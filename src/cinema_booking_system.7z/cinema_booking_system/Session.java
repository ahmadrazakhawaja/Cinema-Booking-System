/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cinema_booking_system;

/**
 *
 * @author Muhammad Affan
 */
public class Session {
    private String date;
    private double timeslot;
    private boolean three_d;
    
    public Session(String date, double timeslot, boolean three_d){
        this.date = date;
        this.timeslot = timeslot;
        this.three_d = three_d;
        
              
    }

    @Override
    public String toString() {
        return "Session:" + "date=" + date + ", timeslot=" + timeslot + ", 3d=" + three_d;
    }
    
}
